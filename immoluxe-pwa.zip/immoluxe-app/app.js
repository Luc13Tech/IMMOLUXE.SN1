// App Data
const services = [
    {
        icon: '🏞️',
        title: 'Vente de Terrains',
        description: 'Des terrains bien situés pour vos projets de construction.'
    },
    {
        icon: '🏢',
        title: 'Location d\'Appartements',
        description: 'Appartements modernes et bien équipés dans les meilleurs quartiers.'
    },
    {
        icon: '🏡',
        title: 'Vente de Villas',
        description: 'Villas de prestige avec des équipements haut de gamme.'
    },
    {
        icon: '🤝',
        title: 'Négociations',
        description: 'Nous négocions les meilleurs prix pour nos clients.'
    },
    {
        icon: '💡',
        title: 'Conseils Clients',
        description: 'Des conseils experts pour faire les bons choix immobiliers.'
    },
    {
        icon: '📐',
        title: 'Conception Architecturale',
        description: 'Création de plans sur mesure pour vos projets de construction.'
    },
    {
        icon: '📊',
        title: 'Suivi des Réalisations',
        description: 'Accompagnement de vos projets du début à la fin.'
    },
    {
        icon: '📈',
        title: 'Consultation',
        description: 'Étude de marché et analyse de rentabilité.'
    }
];

const products = [
    {
        icon: '🏘️',
        title: 'Appartements Premium',
        description: 'Appartements modernes dans les quartiers résidentiels de Dakar.'
    },
    {
        icon: '🏰',
        title: 'Villas de Luxe',
        description: 'Villas spacieuses avec piscine et jardins privés.'
    },
    {
        icon: '🌳',
        title: 'Terrains Constructibles',
        description: 'Parcelles viabilisées dans les zones stratégiques.'
    },
    {
        icon: '🏬',
        title: 'Locaux Commerciaux',
        description: 'Espaces commerciaux aux emplacements premium.'
    }
];

// DOM Elements
const menuBtn = document.getElementById('menuBtn');
const navDrawer = document.getElementById('navDrawer');
const drawerClose = document.getElementById('drawerClose');
const overlay = document.getElementById('overlay');
const navLinks = document.querySelectorAll('.nav-link');
const servicesGrid = document.getElementById('servicesGrid');
const productsGrid = document.getElementById('productsGrid');
const clientForm = document.getElementById('clientForm');
const loading = document.getElementById('loading');
const successMessage = document.getElementById('successMessage');

// PWA Install
let deferredPrompt;
const installPrompt = document.getElementById('installPrompt');
const installBtn = document.getElementById('installBtn');
const dismissBtn = document.getElementById('dismissBtn');

// Navigation Menu
menuBtn.addEventListener('click', () => {
    navDrawer.classList.add('open');
    overlay.classList.add('active');
});

drawerClose.addEventListener('click', closeMenu);
overlay.addEventListener('click', closeMenu);

function closeMenu() {
    navDrawer.classList.remove('open');
    overlay.classList.remove('active');
}

navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        if (link.getAttribute('href').startsWith('#')) {
            e.preventDefault();
            const target = document.querySelector(link.getAttribute('href'));
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
                closeMenu();
            }
        }
    });
});

// Load Services
function loadServices() {
    servicesGrid.innerHTML = services.map(service => `
        <div class="service-card">
            <div class="service-icon">${service.icon}</div>
            <h3>${service.title}</h3>
            <p>${service.description}</p>
        </div>
    `).join('');
}

// Load Products
function loadProducts() {
    productsGrid.innerHTML = products.map(product => `
        <div class="product-card">
            <div class="product-icon">${product.icon}</div>
            <h3>${product.title}</h3>
            <p>${product.description}</p>
        </div>
    `).join('');
}

// Form Submission
clientForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(clientForm);
    const data = Object.fromEntries(formData);
    
    // Show loading
    clientForm.style.display = 'none';
    loading.style.display = 'block';
    
    // Simulate API call
    setTimeout(() => {
        loading.style.display = 'none';
        successMessage.classList.add('show');
        
        // Reset form after 3 seconds
        setTimeout(() => {
            successMessage.classList.remove('show');
            clientForm.style.display = 'block';
            clientForm.reset();
        }, 3000);
        
        // Store in localStorage for offline access
        const submissions = JSON.parse(localStorage.getItem('submissions') || '[]');
        submissions.push({
            ...data,
            timestamp: new Date().toISOString()
        });
        localStorage.setItem('submissions', JSON.stringify(submissions));
        
        console.log('Form submitted:', data);
    }, 2000);
});

// PWA Install Prompt
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    // Show install prompt after 30 seconds
    setTimeout(() => {
        installPrompt.classList.add('show');
    }, 30000);
});

installBtn.addEventListener('click', async () => {
    if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        console.log('Install prompt outcome:', outcome);
        deferredPrompt = null;
    }
    installPrompt.classList.remove('show');
});

dismissBtn.addEventListener('click', () => {
    installPrompt.classList.remove('show');
});

// Handle successful installation
window.addEventListener('appinstalled', () => {
    console.log('App installée avec succès');
    installPrompt.classList.remove('show');
});

// Check if app is running as PWA
function isPWA() {
    return window.matchMedia('(display-mode: standalone)').matches || 
           window.navigator.standalone === true;
}

// Initialize App
function initApp() {
    loadServices();
    loadProducts();
    
    if (isPWA()) {
        console.log('App running as PWA');
    }
    
    // Check for saved form data
    const savedData = localStorage.getItem('formData');
    if (savedData) {
        const data = JSON.parse(savedData);
        Object.keys(data).forEach(key => {
            const input = document.getElementById(key);
            if (input) input.value = data[key];
        });
    }
}

// Save form data on input
clientForm.addEventListener('input', () => {
    const formData = new FormData(clientForm);
    const data = Object.fromEntries(formData);
    localStorage.setItem('formData', JSON.stringify(data));
});

// Smooth scroll for all anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});

// Online/Offline Status
window.addEventListener('online', () => {
    console.log('Back online');
    // You could show a notification here
});

window.addEventListener('offline', () => {
    console.log('Offline mode');
    // You could show a notification here
});

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
} else {
    initApp();
}

// Analytics helper (placeholder)
function trackEvent(category, action, label) {
    console.log('Event:', category, action, label);
    // Add your analytics tracking here
}

// Track page views
trackEvent('Page', 'View', 'Home');
